//machete de países = 'Surinam',  'Ecuador', 'Colombia', 'Brasil'
const arrayVacio = []

const paises = ['Argentina', 'Uruguay', 'Chile', 'Venezuela', 'Antártida', 'Surinam',  'Ecuador', 'Colombia', 'Brasil']
//    índices        0           1         2          3            4
const paisesDelNorte = ['México', 'USA', 'Canada', 'Alaska', 'Cuba', 'Costa Rica', 'Panamá', 'Jamaica', 'Haití', 'Puerto Rico']

function unificarArrays() {
    const paisesDeAmerica = paises.concat(paisesDelNorte) 
    console.table(paisesDeAmerica)
}

function recorrerArray() {
    // FOR CONVENCIONAL
    // for (let i = 0; i < paises.length; i++) {
    //     console.log(paises[i])
    // }
    // FOR...OF
    for (let pais of paises) {
        console.log(pais)
    }
}

function agregarPais() {
    let nuevoPais = prompt("Ingresa el nuevo país:")
    // let indice = paises.indexOf(nuevoPais)
    let existe = paises.includes(nuevoPais)

    if (existe === false) {
        paises.push(nuevoPais)
        console.table(paises)
    } else {
        console.warn("El país ya fue cargado en el array.")
    }

}

// function quitarPais() {
//     // paises.pop()
//     paises.shift()
//     console.table(paises)
// }

function quitarPais() {
    // splice = empalmar
    let paisAquitar = prompt("Ingresa el país a remover del arry:")
    let indice = paises.indexOf(paisAquitar)

    if (indice === -1) {
        console.warn("No se encontró el país indicado:", paisAquitar)
    } else {
        paises.splice(indice, 1)
    }
    console.table(paises)
}

function buscarReemplazar() {
    let buscarPais = prompt("Ingresa el país a buscar:")
    let reemplazarPor = "Guayana Neerlandesa"

    let indice = paises.indexOf(buscarPais)
    paises.splice(indice, 1, reemplazarPor)

    console.table(paises)
}

function ordenarPaises() {
    paises.sort()
    console.table(paises)
}


function cargarPaises() { //NO LE DEMOS BOLILLA A ESTA PARTE
    const listado = document.querySelector("ol")
        listado.innerHTML = ''
        for (pais of paises) listado.innerHTML += `<li>${pais}</li>`
}
cargarPaises()

