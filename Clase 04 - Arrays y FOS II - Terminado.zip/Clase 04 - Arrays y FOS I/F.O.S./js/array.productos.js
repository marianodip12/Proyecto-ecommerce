const productos = [
    { id: 1234, nombre: 'NOTEBOOK EXO E17', importe: 79950, categoria: 'Portátiles' },
    { id: 2345, nombre: 'MACBOOK AIR 13', importe: 749900, categoria: 'Portátiles' },
    { id: 3456, nombre: 'LENOVO IDEAPAD 13', importe: 199949, categoria: 'Portátiles' },
    { id: 4567, nombre: 'LENOVO GAMER 15', importe: 609090, categoria: 'Desktop' },
    { id: 5678, nombre: 'ASUS GAMING PRO 17', importe: 679800, categoria: 'Desktop' },
    { id: 6789, nombre: 'IPAD PRO 12', importe: 219890, categoria: 'Tablets' },
    { id: 7890, nombre: 'PAD DROID 10.1', importe: 119960, categoria: 'Tablets' },
    { id: 8901, nombre: 'ipad MINI 7.9', importe: 229900, categoria: 'Tablets' },
    { id: 9012, nombre: 'SMARTWATCH 1.8', importe: 229900, categoria: 'Relojes' },
    { id: 9110, nombre: 'Smartwatch 1.8', importe: 229900, categoria: 'Relojes' }
]



//Creamos una función para generar números aleatorios.
const creoID = () => parseInt(Math.random() * 10_000)

/*
// ABSTRACCIÓN

function saludar() {
    console.log("Hola, mundo!")
}

function saludar(texto) {
    console.log(texto)
}

function saludar(texto, fn) {
    fn(texto)
}

const numeros = [56, 34, 88, 2, 65, 9]

function sumarNumeros(numeros, fn) {
    let total = 0
    for (let nro of numeros) {
        total += nro
    }

    fn("Total: " + total)
}

*/

function recorrerProductos() { // recorre de principio a fin un array
    productos.forEach((producto)=> {
        console.log(producto)
    })
}

function buscarProducto() {
    // .find() itera de principio a fin el array
    // cuando encuentra la primera coincidencia, retorna el elemento u objeto / deja de iterar el array
    // si no encuentra coincidencia, retorna 'undefined' 

    // let valor = prompt("Ingresa el importe del producto a buscar:")
    // let resultado = productos.find((producto)=> producto.importe === parseInt(valor))
    let valor = prompt("Ingresa el código de producto a buscar:")
    let resultado = productos.find((producto)=> producto.id === parseInt(valor))

    
    if (resultado !== undefined) {
        console.log(resultado)
    } else {
        console.warn("No se encontró un producto con dicho precio.")
    }
}

function filtrarProductos() {
    let parametro = prompt("Ingresa parte del nombre del producto:")
    parametro = parametro.trim().toUpperCase() // encadenamiento de métodos

    let resultado = productos.filter((producto)=> producto.nombre.includes(parametro))
    if (resultado.length > 0) {
        console.table(resultado)
    } else {
        console.warn("No se encontró coincidencia.")
    }
}

function filtrarCategorias() {
    let parametro = prompt("Ingresa la categoría a filtrar:")

    if (parametro !== "") {
        let resultado = productos.filter((producto)=> producto.categoria ===  parametro)
        console.table(resultado)
    }
}


const horarios = ['12:00', '12:30', '13:00', '13:30', '14:00']

function filtrarHorarios() {
    let hora = prompt("let ingresa a partir de qué hora quieres ver los turnos:")

    let horariosDisponibles = horarios.filter((horario)=> horario >= hora)
    console.table(horariosDisponibles)
}

function verProductosSimplificado() {
    let productosSimplificados = productos.map((producto)=> {
        return {
            nombre: producto.nombre,
            importe: producto.importe
        }
    })
    console.table(productosSimplificados)
}

const IVA = 1.18

function verProductosConIVA() {
    let productosSimplificados = productos.map((producto)=> {
        return {
            nombre: producto.nombre,
            importe: producto.importe,
            importeFinal: parseFloat((producto.importe * IVA).toFixed(2))
        }
    })
    console.table(productosSimplificados)
}



// function calcularTotalCarrito() {
//     let DESCUENTO = -15000
//     // let total = carrito.reduce((acc, producto)=> acc + producto.importe, 0)
//     let total = carrito.reduce((acc, producto)=> acc + producto.importe, DESCUENTO)
//     console.log("Total del carrito: $", total)
// }

const numeros = [15, 45, 6, 77, 82, 41]

function sumarNumeros() {
    let total = numeros.reduce((acc, nro)=> acc + nro, 0)
    console.log("Total de la suma:", total)
}

const carrito = [
    { id: 2345, nombre: 'MACBOOK AIR 13', importe: 749900, cantidad: 1},
    { id: 9012, nombre: 'SMARTWATCH 1.8', importe: 229900, cantidad: 4},
    { id: 7890, nombre: 'PAD DROID 10.1', importe: 119960, cantidad: 3}
]

function calcularTotalCarrito() {
    let total = carrito.reduce((acc, producto)=> acc + (producto.importe * producto.cantidad), 0)
    console.log("Total del carrito: $", total)
}



// MÉTODOS DE BÚSQUEDA Y TRANSFORMACIÓN

function ordenarProductosPorNombre() {
    productos.sort((a, b)=> {
        if (a.nombre > b.nombre) {
            return 1
        }
        if (a.nombre < b.nombre) {
            return -1
        }
        return 0
    })

    console.clear()
    console.table(productos)
}

function ordenarProductosPorImporte() {
    productos.sort((a, b)=> {
        if (a.importe > b.importe) return 1
        if (a.importe < b.importe) return -1
        return 0
    })

    console.clear()
    console.table(productos)
}

function ordenarDescendentePorImporte() { 
    // ordenar de manera descendente
    // invertimos signos en oper. de comparación, o en valores de return
    productos.sort((a, b)=> {
        if (a.importe < b.importe) return 1
        if (a.importe > b.importe) return -1
        return 0
    })

    console.clear()
    console.table(productos)
}

/*  MÉTODOS EN ARRAYS SIN ALTERAR ESTRUCTURA DEL ARRAY
    const productosOrdenados = productos.toSorted((a, b)=> {
        if (a.importe > b.importe) return 1
        if (a.importe < b.importe) return -1
        return 0
    })

    const productosCambiado = productos.toSpliced(3, 1)


*/


function utilizarMath() { // obj integrado en JS, con métodos matemáticos / aritméticos
    

}